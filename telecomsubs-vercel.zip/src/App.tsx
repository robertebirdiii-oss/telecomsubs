import React, { useEffect, useMemo, useState } from 'react'
import './index.css'

// ====== CONFIG ======
// Vercel-friendly: set these via environment variables at build time or runtime.
const API_BASE = import.meta.env.VITE_API_BASE || ''   // e.g. 'https://api.example.com'
const USE_API_DEFAULT = (import.meta.env.VITE_USE_API === 'true') || false

// Demo seed data with lat/lng for map
const DEMO_LISTINGS = [
  {
    id: 1,
    name: 'Apex Telecom Services',
    tagline: 'Phone systems, installs & maintenance',
    city: 'Ashburn, VA',
    lat: 39.0436,
    lng: -77.4875,
    categories: ['Phone System Install', 'Repairs & Service'],
    rating: 4.8,
    reviews: 42,
    phone: '(800) 555-0101',
    site: '#',
    image: 'https://images.unsplash.com/photo-1581092795360-fd1ca04f0952?auto=format&fit=crop&w=800&q=60'
  },
  {
    id: 2,
    name: 'FiberWorks LLC',
    tagline: 'Fiber builds & splicing',
    city: 'Chicago, IL',
    lat: 41.8781,
    lng: -87.6298,
    categories: ['Fiber Optic', 'Structured Cabling'],
    rating: 4.6,
    reviews: 19,
    phone: '(312) 555-0142',
    site: '#',
    image: 'https://images.unsplash.com/photo-1518779578993-ec3579fee39f?auto=format&fit=crop&w=800&q=60'
  },
  {
    id: 3,
    name: 'Neighborhood Techs',
    tagline: 'Local phone repair & emergency service',
    city: 'Naperville, IL',
    lat: 41.7508,
    lng: -88.1535,
    categories: ['Repairs & Service'],
    rating: 4.2,
    reviews: 8,
    phone: '(630) 555-0198',
    site: '#',
    image: 'https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=60'
  }
]

export default function App() {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All')
  const [useApi, setUseApi] = useState(USE_API_DEFAULT)
  const [listings, setListings] = useState(DEMO_LISTINGS)
  const [loading, setLoading] = useState(false)
  const [tab, setTab] = useState('market')
  const [zip, setZip] = useState('')
  const [radius, setRadius] = useState(50)

  const categories = useMemo(() => (
    ['All', 'Phone System Install', 'Structured Cabling', 'Fiber Optic', 'Repairs & Service', 'VoIP Providers']
  ), [])

  useEffect(() => {
    async function load() {
      if (!useApi || !API_BASE) return setListings(DEMO_LISTINGS)
      try {
        setLoading(true)
        if ((/^[0-9]{5}$/.test(String(zip)))) {
          const res = await fetch(API_BASE + '/api/search?zip=' + zip + '&radius=' + radius)
          const data = await res.json()
          setListings(data.results || data)
        } else {
          const res = await fetch(API_BASE + '/api/listings')
          const data = await res.json()
          setListings(data)
        }
      } catch (e) {
        console.error(e)
        setListings(DEMO_LISTINGS)
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [useApi, zip, radius])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    return listings.filter(l => {
      const matchesCategory = category === 'All' || l.categories?.includes(category)
      const matchesQuery = !q || [l.name, l.tagline, l.city].some(v => v?.toLowerCase().includes(q))
      return matchesCategory && matchesQuery
    })
  }, [listings, query, category])

  return (
    <div className="min-h-screen bg-gray-50 text-slate-800">
      <Header onSignInClick={() => alert('Hook up your auth here.')} />

      <main className="container mx-auto px-6 py-8">
        <Hero query={query} setQuery={setQuery} zip={zip} setZip={setZip} radius={radius} setRadius={setRadius} />

        <div className="mt-6 flex items-center gap-3 text-sm">
          <label className="flex items-center gap-2"><input type="checkbox" checked={useApi} onChange={e => setUseApi(e.target.checked)} /> Use API</label>
          <span className="text-slate-500">{useApi ? (loading ? 'Loading from API…' : 'Live API mode') : 'Demo data mode'}</span>
        </div>

        <div className="mt-6 flex items-center justify-between">
          <Tabs value={tab} onChange={setTab} items={[{id:'market',label:'Marketing Page'},{id:'directory',label:'Directory'},{id:'admin',label:'Admin'}]} />
          <div className="flex items-center gap-3">
            <span className="text-sm text-slate-600">Category</span>
            <select value={category} onChange={e => setCategory(e.target.value)} className="border border-slate-200 rounded px-2 py-1 text-sm">
              {categories.map(c => <option key={c}>{c}</option>)}
            </select>
            <button onClick={() => { setQuery(''); setCategory('All') }} className="text-sm underline">Clear</button>
          </div>
        </div>

        {tab === 'market' ? (
          <MarketingBlock />
        ) : tab === 'directory' ? (
          <section className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
            <div className="md:col-span-2">
              <DirectoryList listings={filtered} />
            </div>
            <aside className="hidden md:block">
              <Sidebar categories={categories} onPick={setCategory} />
            </aside>
          </section>
        ) : (
          <AdminPanel apiBase={API_BASE} />
        )}

        <section id="map" className="mt-12">
          <MapSection listings={filtered} />
        </section>

        <Pricing />
      </main>

      <Footer />
    </div>
  )
}

function Header({ onSignInClick }: { onSignInClick: () => void }) {
  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img src="/placeholder-logo.png" alt="TelecomSubs" className="h-10 w-auto" />
          <div>
            <h1 className="text-xl font-semibold">TelecomSubs</h1>
            <p className="text-xs text-slate-500">Find vetted telecom contractors near you</p>
          </div>
        </div>
        <nav className="hidden md:flex gap-6 items-center text-sm">
          <a className="hover:text-sky-600" href="#how">How it works</a>
          <a className="hover:text-sky-600" href="#directory">Contractors</a>
          <a className="hover:text-sky-600" href="#pricing">Pricing</a>
          <a className="hover:text-sky-600" href="#contact">Contact</a>
          <button onClick={onSignInClick} className="ml-2 px-4 py-2 bg-sky-600 text-white rounded-lg">Sign In</button>
        </nav>
      </div>
    </header>
  )
}

function Hero({ query, setQuery, zip, setZip, radius, setRadius }: { query: string; setQuery: (v: string) => void; zip: string; setZip: (v:string)=>void; radius: number; setRadius: (n:number)=>void }) {
  // optional: Google Places autocomplete if window.GMAPS_KEY is present
  useEffect(() => {
    const key = (typeof window !== 'undefined') && (window as any).GMAPS_KEY
    if (!key) return
    const existing = document.getElementById('google-maps-js') as HTMLScriptElement | null
    const initPlaces = () => {
      // @ts-ignore
      const google = (window as any).google
      const input = document.getElementById('zip-input') as HTMLInputElement | null
      if (!input) return
      try {
        const ac = new google.maps.places.Autocomplete(input, { types: ['(regions)'], fields: ['address_components'] })
        ac.addListener('place_changed', () => {
          const p = ac.getPlace()
          const comp = (p.address_components||[]).find((c:any)=>c.types.includes('postal_code'))
          if (comp) setZip(comp.long_name)
        })
      } catch {}
    }
    if (!existing) {
      const s = document.createElement('script')
      s.id = 'google-maps-js'
      s.src = `https://maps.googleapis.com/maps/api/js?key=${key}&libraries=places`
      s.async = True
      s.onload = initPlaces
      document.body.appendChild(s)
    } else {
      initPlaces()
    }
  }, [])

  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
      <div className="md:col-span-2">
        <h2 className="text-3xl font-extrabold">Find Local Telecom Contractors & Phone System Installers</h2>
        <p className="mt-3 text-slate-600">Enter a city or service (e.g., "fiber splicing") or filter by ZIP & radius. Search is free for customers.</p>
        <div className="mt-6 bg-white p-4 rounded-xl shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
            <div className="flex gap-3 col-span-2">
              <input
                aria-label="Search companies, city, or service"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search city, company, or service"
                className="flex-1 border border-slate-200 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-sky-300"
              />
              <button className="px-4 py-3 bg-sky-600 text-white rounded-lg">Search</button>
            </div>
            <div className="flex gap-2 items-center">
              <input id="zip-input" value={zip} onChange={e=>setZip(e.target.value)} placeholder="ZIP (optional)" className="border border-slate-200 rounded px-3 py-2 w-28"/>
              <input type="number" min={5} max={500} value={radius} onChange={e=>setRadius(Number(e.target.value)||50)} placeholder="mi" className="border border-slate-200 rounded px-3 py-2 w-24"/>
              <span className="text-sm text-slate-500">mi</span>
            </div>
          </div>
          <p className="mt-2 text-xs text-slate-500">ZIP+radius filters apply when API mode is on.</p>
        </div>
      </div>
      <PromoCard />
    </section>
  )
}

function PromoCard() {
  return (
    <aside className="bg-gradient-to-br from-emerald-500 to-sky-600 text-white p-5 rounded-2xl shadow-md">
      <h4 className="text-lg font-semibold">Get Listed on All 3 Sites</h4>
      <p className="text-sm mt-1 opacity-90">Sign up on TelecomSubs.com and your first year on Uzilla.com and PhoneInstallers.com is free.</p>
      <a href="#" className="mt-3 inline-block px-4 py-2 bg-white text-slate-800 rounded-lg">List Your Business</a>
    </aside>
  )
}

function Tabs({ value, onChange, items }: { value: string; onChange: (v: string) => void; items: {id:string,label:string}[] }) {
  return (
    <div className="inline-flex border border-slate-200 rounded-lg overflow-hidden">
      {items.map((it) => (
        <button key={it.id} onClick={() => onChange(it.id)} className={`px-4 py-2 text-sm ${value===it.id? 'bg-slate-900 text-white':'bg-white text-slate-700'}`}>{it.label}</button>
      ))}
    </div>
  )
}

function MarketingBlock() {
  return (
    <section className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6" id="how">
      <div className="bg-white p-6 rounded-xl shadow">
        <h3 className="text-lg font-semibold">1. Search by ZIP</h3>
        <p className="text-slate-600 mt-1">Instantly see vetted contractors near your job site. It’s free for customers.</p>
      </div>
      <div className="bg-white p-6 rounded-xl shadow">
        <h3 className="text-lg font-semibold">2. Compare & Contact</h3>
        <p className="text-slate-600 mt-1">Check services, coverage, ratings, and request quotes in minutes.</p>
      </div>
      <div className="bg-white p-6 rounded-xl shadow">
        <h3 className="text-lg font-semibold">3. Get Work Done</h3>
        <p className="text-slate-600 mt-1">Your project matched with reliable pros for cabling, fiber, VoIP, and more.</p>
      </div>
    </section>
  )
}

function DirectoryList({ listings }: { listings: typeof DEMO_LISTINGS }) {
  if (!listings.length) return (<div className="p-6 bg-white rounded-lg shadow text-center text-slate-600">No results found. Try a different city or category.</div>)
  return (
    <div id="directory" className="mt-6 grid grid-cols-1 gap-4">
      {listings.map(l => (
        <article key={l.id} className="p-4 bg-white rounded-lg shadow flex gap-4 items-center">
          <img src={l.image} alt={l.name} className="w-28 h-20 object-cover rounded-md" />
          <div className="flex-1">
            <h3 className="text-lg font-semibold">{l.name}</h3>
            <p className="text-sm text-slate-600">{l.tagline} — <span className="font-medium">{l.city}</span></p>
            <div className="mt-2 flex items-center gap-3 text-sm text-slate-500">
              <div>⭐ {l.rating} ({l.reviews} reviews)</div>
              <div className="px-2 py-1 bg-slate-100 rounded">{l.categories?.join(', ')}</div>
            </div>
          </div>
          <div className="text-right">
            <a href={l.site || '#'} className="inline-block px-4 py-2 border border-sky-600 text-sky-600 rounded-lg">View</a>
          </div>
        </article>
      ))}
    </div>
  )
}

function Sidebar({ categories, onPick }: { categories: string[]; onPick: (v: string)=>void }) {
  return (
    <div className="sticky top-24 space-y-4">
      <div className="bg-white p-4 rounded-lg shadow">
        <h4 className="font-semibold">Top Categories</h4>
        <ul className="mt-2 text-sm text-slate-600 space-y-1">
          {categories.slice(1).map(c => (
            <li key={c}><button onClick={() => onPick(c)} className="text-left w-full hover:text-sky-600">{c}</button></li>
          ))}
        </ul>
      </div>
      <div className="bg-white p-4 rounded-lg shadow">
        <h4 className="font-semibold">Get Listed</h4>
        <p className="text-sm text-slate-600 mt-2">Boost visibility — add your company to appear in searches and leads.</p>
        <a href="#" className="mt-3 inline-block w-full text-center px-3 py-2 bg-emerald-500 text-white rounded">List Your Business</a>
      </div>
    </div>
  )
}

function MapSection({ listings }: { listings: typeof DEMO_LISTINGS }) {
  useEffect(() => {
    const key = (typeof window !== 'undefined') && (window as any).GMAPS_KEY
    if (!key) return

    const existing = document.getElementById('google-maps-js') as HTMLScriptElement | null
    const initMap = () => {
      // @ts-ignore
      const google = (window as any).google
      const map = new google.maps.Map(document.getElementById('ts-map') as HTMLElement, {
        center: { lat: 39, lng: -96 },
        zoom: 4,
        mapTypeControl: false,
      })
      listings.forEach(l => {
        if (typeof l.lng !== 'number' || typeof l.lat !== 'number') return
        const marker = new google.maps.Marker({ position: { lat: l.lat, lng: l.lng }, map, title: l.name })
        const info = new google.maps.InfoWindow({ content: `<strong>${l.name}</strong><br/>${l.city}` })
        marker.addListener('click', () => info.open({ map, anchor: marker }))
      })
    }

    if (!existing) {
      const s = document.createElement('script')
      s.id = 'google-maps-js'
      s.src = `https://maps.googleapis.com/maps/api/js?key=${key}&libraries=places`
      s.async = true
      s.onload = initMap
      document.body.appendChild(s)
    } else {
      initMap()
    }
  }, [listings])

  return (
    <div>
      <h3 className="text-xl font-semibold">Map View</h3>
      <div id="ts-map" className="mt-4 bg-white h-64 rounded-lg shadow flex items-center justify-center text-slate-400">{(typeof window !== 'undefined' && (window as any).GMAPS_KEY) ? 'Loading map…' : 'Set window.GMAPS_KEY to enable Google Maps'}</div>
    </div>
  )
}

function Pricing() {
  return (
    <section id="pricing" className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
      <Plan title="Free Listing" cta="Get Listed" color="sky" features={["Company name & phone","1 service category","Location"]} />
      <Plan title="Pro Listing" cta="Upgrade" color="emerald" features={["Featured placement","Multiple service categories","Lead emails"]} />
      <Plan title="Nationwide / Lifetime" cta="Contact Sales" color="orange" features={["Unlimited areas","Lifetime option","Priority leads"]} />
    </section>
  )
}

function Plan({ title, cta, features, color }: { title: string; cta: string; features: string[]; color: 'sky'|'emerald'|'orange' }) {
  const btn = { sky: 'bg-sky-600', emerald: 'bg-emerald-500', orange: 'bg-orange-500' }[color]
  return (
    <div className="bg-white p-6 rounded-lg shadow text-center">
      <h4 className="text-lg font-semibold">{title}</h4>
      <p className="mt-2 text-slate-600">Everything you need to get discovered.</p>
      <ul className="mt-4 text-sm text-left list-disc list-inside">{features.map(f => <li key={f}>{f}</li>)}</ul>
      <a href="#" className={`mt-4 inline-block px-4 py-2 text-white rounded ${btn}`}>{cta}</a>
    </div>
  )
}

function Footer() {
  return (
    <footer id="contact" className="bg-slate-900 text-slate-200 mt-12">
      <div className="container mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <img src="/placeholder-logo-white.png" alt="TelecomSubs" className="h-10 mb-3" />
          <p className="text-sm text-slate-400">Connect with vetted telecom contractors across the U.S.</p>
        </div>
        <div>
          <h5 className="font-semibold">Company</h5>
          <ul className="mt-2 text-sm text-slate-400 space-y-1">
            <li><a className="hover:text-white" href="#">About</a></li>
            <li><a className="hover:text-white" href="#">Pricing</a></li>
            <li><a className="hover:text-white" href="#">Support</a></li>
          </ul>
        </div>
        <div>
          <h5 className="font-semibold">Contact</h5>
          <p className="text-sm text-slate-400 mt-2">support@example.com<br/>(800) 555-0123</p>
          <AuthModalTrigger />
        </div>
      </div>
      <div className="bg-slate-800 text-slate-500 text-xs text-center py-4">© {new Date().getFullYear()} TelecomSubs — Demo clone. Replace with your legal footer.</div>
    </footer>
  )
}

function AuthModalTrigger() {
  const [open,setOpen] = useState(false)
  return (
    <div className="mt-4">
      <button onClick={()=>setOpen(true)} className="px-3 py-2 text-sm bg-white text-slate-900 rounded">Sign in / List your business</button>
      {open && <AuthModal onClose={()=>setOpen(false)} />}
    </div>
  )
}

function AuthModal({ onClose }:{ onClose: ()=>void }) {
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const [token,setToken] = useState<string|undefined>()
  const login = async () => {
    try{
      const res = await fetch((API_BASE||'') + '/api/auth/login',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password}) })
      const data = await res.json()
      if(data.token){ setToken(data.token); try{ localStorage.setItem('ts_token', data.token) } catch {} }
    }catch(e){ console.error(e) }
  }
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-sm w-full p-5 shadow-xl">
        <div className="flex items-center justify-between">
          <h4 className="font-semibold">Sign in</h4>
          <button onClick={onClose} className="text-slate-500">✕</button>
        </div>
        {!token ? (
          <div className="mt-4 space-y-3">
            <input className="w-full border border-slate-200 rounded px-3 py-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
            <input type="password" className="w-full border border-slate-200 rounded px-3 py-2" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
            <button onClick={login} className="w-full bg-sky-600 text-white rounded px-3 py-2">Continue</button>
            <p className="text-xs text-slate-500">New here? Use the form below to list your business.</p>
            <ListBusinessForm />
          </div>
        ) : (
          <div className="mt-4">
            <p className="text-sm">Logged in. Your token: <span className="font-mono text-xs">{token}</span></p>
            <p className="text-xs text-slate-500">(Use real auth in production.)</p>
          </div>
        )}
      </div>
    </div>
  )
}

function ListBusinessForm(){
  const [form,setForm] = useState({ name:'', city:'', phone:'', categories:'Phone System Install', lat:'', lng:'' })
  const [created,setCreated] = useState<any>(null)
  const submit = async (e:any) => {
    e.preventDefault()
    const payload = { ...form, lat: Number(form.lat)||null, lng: Number(form.lng)||null, categories: [form.categories] }
    const res = await fetch((API_BASE||'') + '/api/listings',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) })
    const data = await res.json()
    setCreated(data)
  }
  return (
    <form onSubmit={submit} className="mt-4 space-y-3 border-top pt-3">
      <input required placeholder="Company name" className="w-full border border-slate-200 rounded px-3 py-2" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
      <input placeholder="City, ST" className="w-full border border-slate-200 rounded px-3 py-2" value={form.city} onChange={e=>setForm({...form,city:e.target.value})}/>
      <input placeholder="Phone" className="w-full border border-slate-200 rounded px-3 py-2" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/>
      <select className="w-full border border-slate-200 rounded px-3 py-2" value={form.categories} onChange={e=>setForm({...form,categories:e.target.value})}>
        <option>Phone System Install</option><option>Structured Cabling</option><option>Fiber Optic</option><option>Repairs & Service</option><option>VoIP Providers</option>
      </select>
      <div className="grid grid-cols-2 gap-2">
        <input placeholder="Latitude" className="w-full border border-slate-200 rounded px-3 py-2" value={form.lat} onChange={e=>setForm({...form,lat:e.target.value})}/>
        <input placeholder="Longitude" className="w-full border border-slate-200 rounded px-3 py-2" value={form.lng} onChange={e=>setForm({...form,lng:e.target.value})}/>
      </div>
      <button className="w-full bg-emerald-500 text-white rounded px-3 py-2">Create Listing</button>
      {created && <p className="text-xs text-emerald-700">Created listing #{created.id}: {created.name}</p>}
    </form>
  )
}

function AdminPanel({ apiBase }:{ apiBase:string }){
  const [rows,setRows] = useState<any[]>([])
  const [loading,setLoading] = useState(false)
  const token = (()=>{ try{ return localStorage.getItem('ts_token') }catch{ return null } })()
  const headers = token ? { Authorization: 'Bearer '+token } : {}
  const load = async () => {
    setLoading(true)
    const r = await fetch(apiBase + '/api/listings')
    const data = await r.json()
    setRows(data)
    setLoading(false)
  }
  useEffect(()=>{ load() },[])
  const act = async (id:number, path:string) => {
    await fetch(apiBase + path, { method:'PATCH', headers })
    load()
  }
  return (
    <section className="mt-8">
      <h3 className="text-xl font-semibold">Admin — Listings</h3>
      {loading ? <p className="text-sm text-slate-500 mt-2">Loading…</p> : (
        <div className="mt-4 overflow-auto">
          <table className="min-w-full text-sm">
            <thead><tr className="text-left"><th className="p-2">ID</th><th className="p-2">Name</th><th className="p-2">City</th><th className="p-2">Approved</th><th className="p-2">Featured</th><th className="p-2">Actions</th></tr></thead>
            <tbody>
              {rows.map((r:any) => (
                <tr key={r.id} className="border-t">
                  <td className="p-2">{r.id}</td>
                  <td className="p-2">{r.name}</td>
                  <td className="p-2">{r.city}</td>
                  <td className="p-2">{r.approved? 'Yes':'No'}</td>
                  <td className="p-2">{r.featured? 'Yes':'No'}</td>
                  <td className="p-2 space-x-2">
                    <button onClick={()=>act(r.id, `/api/listings/${r.id}/approve`)} className="px-2 py-1 text-xs bg-emerald-600 text-white rounded">Approve</button>
                    <button onClick={()=>act(r.id, `/api/listings/${r.id}/feature`)} className="px-2 py-1 text-xs bg-orange-600 text-white rounded">Feature</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p className="text-xs text-slate-500 mt-2">Use an admin token (requires JWT server) to enable actions.</p>
    </section>
  )
}
